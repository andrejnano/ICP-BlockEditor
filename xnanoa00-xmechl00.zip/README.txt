Aplikace BlockEditor

projekt do predmetu ICP 2018
Fakulta Informacnich Technologii, VUT BRNO
6.5.2018

Andrej Nano, xnanoa00
Stanislav Mechl, xmechl00


Aplikace umoznuje vytvaret, editovat, ukladat a nacitat blokova schemata.
Schemata jsou slozena z bloku a propoju mezi nimi.
Po sestaveni nebo nacteni schematu lze provest vypocet.